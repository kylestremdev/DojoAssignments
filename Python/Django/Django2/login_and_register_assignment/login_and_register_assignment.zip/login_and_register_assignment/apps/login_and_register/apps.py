from __future__ import unicode_literals

from django.apps import AppConfig


class LoginAndRegisterConfig(AppConfig):
    name = 'login_and_register'
