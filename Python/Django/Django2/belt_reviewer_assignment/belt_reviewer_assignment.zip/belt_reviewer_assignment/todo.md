Todo: Style and handle a few errors

- Repeating books on users show page
- Stars for ratings?
